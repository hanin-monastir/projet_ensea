public class Test{

	public static void main(String [] args){
	
		Fenetre fenetre = new Fenetre("Cartographie aérienne et Géoréférencement");
	}
}


