import java.io.*;
import javax.imageio.ImageIO;
import java.net.*;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.* ;
import java.lang.* ;

public class Itineraire{
	/**
	*	 Un tableau à 2 éléments de latitude qui sera utilisé pour calculer les caps et distance
	*/	
	private double[] latitude;
	/**
	*	 Un tableau à 2 éléments de longitude 
	*/
	private double[] longitude;
	/**
	*	l'adresse qui sera envoyé à google
	*/
	private String url;
	/**
	*	L'image retournée par google
	*/	
	private BufferedImage map;
	/**
	*	Le facteur de zoom demandée à google
	*/
	private int zoom;
	/**
	*	Le type de vue demandée satellite par défaut
	*/
	private String vue;
	/**
	*	taille de l'image demandée
	*/
	private int size;
	/**
	*	la distance qui servira lors des calculs de breakpoints
	*/	
	private double distance;
	/**	
	*	Une arraylist qui contiendra des breakpoints intermédiaires
	*/
	private ArrayList<double[]> breakpoint;
	/**
	*	une arraylist qui contiendra les breakpoints d'un premier coté du champs
	*/
	private ArrayList<double[]> base1;
	/**
	*	une arraylist qui contient les breakpoints du deuxième coté
	*/
	private ArrayList<double[]> base2;
	/**
	*	l'arraylist finale qui contiendra le parcourt
	*	google peut refuser de retourner l'itinéraire si sa taille est trop importante
	*/
	private ArrayList<double[]> finale;
	/**
	*	Arraylist qui contient que le chemin liant les bords et ne contenant pas les breakpoints intermédiare
	*/
	private ArrayList<double[]> chemin;
	/**
	*	Arraylist pour les breakpoints de l'arc de cercle
	*/
	private ArrayList<double[]> arc;
	/**
	*	Tableau qui contiendra les latitudes lors du chargement du fichier de config	
	*/
	double[] lat;
	/**
	*	Tableau qui contiendra les longitudes lors de la lecture du fichier de config
	*/
	double[] lon;
	/**
	*	Espace inter-breakponts
	*/
	private double espace;	
	/**
	*	nombre de breakpoint nécéssaire, calculé dans le constructeur
	*/
	private int nbkp;
	/**
	*	Permet de connaitre le sens de parcours
	*/
	private String sens;
	/**
	*	Enregistre l'ancien cap voir si utiie pour trouver les breakpoints dans les arcs de cercle
	*/
	private double oldcap;
	/**
	*	Cap actuel
	*/
	private double cap;

        /**
         * Constructeur Itineraire
         * <p>
         * A la construction d'un objet Itinéraire, on charge les paramètres présent dans le fichier
	 * itinéraire.txt
	 * On construit une adresse web compréhensible par Google, regroupant le passage de l'avion path et 
	 * les markeurs.
	 * Le calcul de la position des markeurs se fait en interne, par calcul de cap et grâce à la distance
	 * demandée par l'utilisateur
         * </p>
         * 
         */
	Itineraire(){
		//4 points seront nécéssaires
		String sens = "positif";
		vue = "satellite";

		latitude = new double[2];
		longitude = new double[2];
		lat = new double[4];
		lon = new double[4];
		boolean chargement = loadConfig();
		//construction de la base 1
		/*espace = space;
		zoom = z;
		size = s;
		*/
		if(chargement){ 
			latitude[0] = lat[0];
			longitude[0] = lon[0];
			latitude[1] = lat[3];
			longitude[1] = lon[3];
			
			//on créé la liste de breakpoint	
			breakpoint = new ArrayList<double[]>();
		
			double[] bkp = new double[2];
			bkp[0] = latitude[0];
			bkp[1] = longitude[1];		
			breakpoint.add(bkp);

			//on calcul la distance entre les deux points
			calculDistance();
	
			//on calcul le nombre de breakpoint nécéssaire en fonction de l'espace choisit
			nbkp = (int)(distance/espace);
		
			//on obtient la liste de breakpoint
			getBreakPoint();

			//on obtient les points de la première base
			base1 = new ArrayList<double[]>(breakpoint);		
			breakpoint.clear();
		
			//on fait de meme avec la base2	
			//construction de la base 2
			latitude[0] = lat[1];
			longitude[0] = lon[1];
			latitude[1] = lat[2];
			longitude[1] = lon[2];
		
			//on créé la liste de breakpoint	
			breakpoint = new ArrayList<double[]>();
			bkp = new double[2];
			bkp[0] = latitude[0];
			bkp[1] = longitude[1];		
			breakpoint.add(bkp);

			//on calcul la distance entre les deux points
			calculDistance();
	
			//on calcul le nombre de breakpoint nécéssaire en fonction de l'espace choisit
			nbkp = (int)(distance/espace);
		
			//on calcul la liste de breakpoint pour la deuxième base		
			getBreakPoint();
	
			//on obtient les points de la deuxième base
			base2 = new ArrayList<double[]>(breakpoint);		
			breakpoint.clear();
	
			finale = new ArrayList<double[]>();
			chemin = new ArrayList<double[]>();
	
			//on a maintenant les deux bases ie les breakpionts de deux cotés opposés
			//pour chaque couple de breakpoint de la base on applique la méthode
			if (base1.size() == base2.size() && !base1.isEmpty()){
				//les deux bases ont bien la même taille
				for (int i = 0;i<base1.size();i++){
					latitude[0] = base1.get(i)[0];
					longitude[0] = base1.get(i)[1];
					latitude[1] = base2.get(i)[0];
					longitude[1] = base2.get(i)[1];
			
					//on créé la liste de breakpoint	
					breakpoint = new ArrayList<double[]>();
					bkp = new double[2];
				
						
					//on ajoute le premier
					bkp[0] = latitude[0];
					bkp[1] = longitude[0];	
					
					breakpoint.add(bkp);
					//on calcul la distance entre les deux points
					calculDistance();
					
					//on calcul le nombre de breakpoint nécéssaire en fonction de l'espace choisit
					nbkp = (int)(distance/espace);
					
					getBreakPoint();
					//on ajoute les pins suivant le sens de parcourt
					if(sens == "positif" ){
						//avant l'ajout des marqueurs il faut voir pour ajouter des marqueurs de virage
						oldcap = cap;
						cap = 180/Math.PI*getBearing();
						double diff = cap - oldcap;
						System.out.println("cap " + diff);	
	
						//on obtient les points du virage
						/*if(!finale.isEmpty()){
							getArcPoint(diff);
							for(double[] p : arc){
								//finale.add(p);
								System.out.println(p[0] + " " + p[1]);
							}					
						}*/
	
						for(int k = 0;k<breakpoint.size();k++){
							finale.add(breakpoint.get(k));
						}
	
						//chemin.add(breakpoint.get(0));
						sens = "négatif";
					}
					else
					{			
						oldcap = cap;
						cap = -180/Math.PI*getBearing();
						double diff = cap -oldcap;	
						System.out.println("cap " + diff);
						
						//on obtient les points qui constituent l'arc de cercle
						/*if( i != 0){
							getArcPoint(diff);
							for(double[] p : arc){
								//finale.add(p);
								System.out.println(p[0] + " " + p[1]);
							}					
						}*/
						for(int k = breakpoint.size()-1;k>=0;k--){
							finale.add(breakpoint.get(k));
						}
						//chemin.add(breakpoint.get(breakpoint.size()-1));
						sens = "positif";
					}
					//on libère le breakpoint
					breakpoint.clear();
				}
			}	
			//possible si il y a peu de points sinon google refuse
			chemin = new ArrayList<double[]>(finale);
			//on construit l'adresse à envoyer à google mais google ne peut pas traiter l'adresse résultante
			url = "http://maps.googleapis.com/maps/api/staticmap?path=color:0x0000ff|weight:5|";		
	
			//on continue la construction de l'adresse
			for(int k = 0; k<chemin.size()-1;k++){
				url += chemin.get(k)[0] + "," + chemin.get(k)[1] + "|";
			}
					
			//on ajoute la dernière pin
			url += chemin.get(chemin.size()-1)[0] + "," + chemin.get(chemin.size()-1)[1] + "&";			
	
			if (zoom <= 19 && zoom>=1){
				url += "zoom=" + zoom;
			}


			url += "&" + "size=" + size + "x" + size + "&markers=color:blue%7Clabel:S|";
	
	
			//on ajoute des marqeurs
			for(int k = 0; k<chemin.size()-1;k++){
				url += chemin.get(k)[0] + "," + chemin.get(k)[1] + "|";
			}
	 		url += chemin.get(chemin.size()-1)[0] + "," + chemin.get(chemin.size()-1)[1] +"&";			
			
			url +=  "&maptype=" + vue + "&sensor=true";
				
			try {
				//on récupère l'image envoyé par google
	    			map = ImageIO.read(new URL(url));
			} catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			ShowError("Configurer l'itinéraire avant de le construire");	
		}
	}
	/**
	*	Calcul la distance entre 2 points grâce à leurs coordonnées
	*/
	public void calculDistance(){
		distance = 1000*Math.acos(Math.sin(Math.PI/180*latitude[0])*Math.sin(Math.PI/180*latitude[1])+Math.cos(Math.PI/180*latitude[0])*Math.cos(Math.PI/180*latitude[1])*Math.cos(Math.PI/180*longitude[1]-Math.PI/180*longitude[0]))*6371;
	}

	/**
	*	Trouve le point milieu ente deux points
	*/
	public void midPoint(){
		double lat1 = Math.PI/180*latitude[0];
		double lon1 = Math.PI/180*longitude[0];

		double lat2 = Math.PI/180*latitude[1];
		double lon2 = Math.PI/180*longitude[1];

		double Bx = Math.cos(lat2) * Math.cos(lon2-lon1);
		double By = Math.cos(lat2) * Math.sin(lon2-lon1);
		
		double lat3 = Math.atan2(Math.sin(lat1)+Math.sin(lat2), Math.sqrt((Math.cos(lat1)+Bx)*(Math.cos(lat1)+Bx) + By*By )); 
		double lon3 = lon1 + Math.atan2(By, Math.cos(lat1) + Bx);
	
		System.out.println("Milieu: " + 180/Math.PI*lat3 + " " + 180/Math.PI*lon3);	
	}
	
	/**
	*	Calcul le cap pour se rendre d'un point a à un point b
	*/
	public double getBearing(){
		double lat1 = Math.PI/180*latitude[0];
		double lon1 = Math.PI/180*longitude[0];

		double lat2 = Math.PI/180*latitude[1];
		double lon2 = Math.PI/180*longitude[1];

		double dLon = lon2 - lon1;

		double y = Math.sin(dLon) * Math.cos(lat2);
		double x = Math.cos(lat1)*Math.sin(lat2) - Math.sin(lat1)*Math.cos(lat2)*Math.cos(dLon);
		double bearing = Math.atan2(y, x);
		return bearing;
	}	

	/**
	*	Calcul la position des breakpoints
	*/
	public void getBreakPoint(){
		double d = espace;
		double R = 6371*1000;
		double brng = getBearing();

		double lat0 = latitude[0];
		double lon0 = longitude[0];

		for(int i = 0;i<nbkp;i++){
			double lat1 = Math.PI/180*lat0;
			double lon1 = Math.PI/180*lon0;
		
			double lat2 = Math.asin(Math.sin(lat1)*Math.cos(d/R) + Math.cos(lat1)*Math.sin(d/R)*Math.cos(brng));
			double lon2 = lon1 + Math.atan2(Math.sin(brng)*Math.sin(d/R)*Math.cos(lat1), Math.cos(d/R)-Math.sin(lat1)*Math.sin(lat2));
			
			lat2 *= 180/Math.PI;
			lon2 *= 180/Math.PI;

			lat0 = lat2;
			lon0 = lon2;
				
			//pour finir on ajoute le breakpoint	
			double[] bkp = new double[2];
			bkp[0] = lat2;
			bkp[1] = lon2; 	

			breakpoint.add(bkp);
		}

		double[] bkp = new double[2];
		bkp[0] = latitude[1];
		bkp[1] = longitude[1]; 	
		breakpoint.add(bkp);
	}

	/**
	*	Tentative pour obtenir des markeurs formant un arc de cercle en bout de chemin
	*/
	public void getArcPoint(double diff){
		double d = espace/3;
		double R = 6371*1000;
		double brng = oldcap;
	
		//3 points interpoints
		int nbp = (int)(diff/3);	

		arc = new ArrayList<double[]>();
		double lat0;
		double lon0;

		//point de départ 
		//on part du dernier point	
		lat0 = finale.get(finale.size()-1)[0];
		lon0 = finale.get(finale.size()-1)[1];

		for (int j = 0; j<3; j++){
			double lat1 = Math.PI/180*lat0;
			double lon1 = Math.PI/180*lon0;
		
			double lat2 = Math.asin(Math.sin(lat1)*Math.cos(d/R) + Math.cos(lat1)*Math.sin(d/R)*Math.cos(brng));
			double lon2 = lon1 + Math.atan2(Math.sin(brng)*Math.sin(d/R)*Math.cos(lat1), Math.cos(d/R)-Math.sin(lat1)*Math.sin(lat2));

			lat2 *= 180/Math.PI;
			lon2 *= 180/Math.PI;

			lat0 = lat2;
			lon0 = lon2;								

			double[] bkp = new double[2];
			bkp[0] = lat2;
			bkp[1] = lon2; 	

		
			arc.add(bkp);
		}
	}

	/**
	*	Charger la configuration si elle existe
	*/
	public boolean loadConfig(){
		boolean chargement=false;
		try{		
			File monFichier = new File("itineraire.txt");
			if (monFichier.exists()){			
				FileReader fichierlu = new FileReader(monFichier);
				BufferedReader bufferlu = new BufferedReader(fichierlu);
				String ligne = "";
				String[] resultat = null;
	
				while ((ligne = bufferlu.readLine()) != null) {	
					resultat = ligne.split(" ");
					switch(resultat[0]){				
						case "Zoom" : 
								zoom = Integer.parseInt(resultat[1]);
								break;
						case "Espace" : 
								espace = Integer.parseInt(resultat[1]);
								break;
						case "Taille"  : 
								size = Integer.parseInt(resultat[1]);
								break;
						case "Point1" :
								lat[0] = Double.parseDouble(resultat[2]);
								lon[0] = Double.parseDouble(resultat[4]);
								break;
						case "Point2" :
								lat[1] = Double.parseDouble(resultat[2]);
								lon[1] = Double.parseDouble(resultat[4]);
								break;
						case "Point3" :
								lat[2] = Double.parseDouble(resultat[2]);
								lon[2] = Double.parseDouble(resultat[4]);
								break;
						case "Point4" :
								lat[3] = Double.parseDouble(resultat[2]);
								lon[3] = Double.parseDouble(resultat[4]);
								break;
						default : break;
					}
				}
				chargement=true;
			}
			else
			{
				chargement=false;
			}
		} catch(Exception ei){
			ei.printStackTrace();
		}
		return chargement;		
	}

	/**
	*	Permet de retourner la liste de breakpoints
	*/
	public ArrayList<double[]> getListBreakPoint(){
		return finale;
	}		

	/**
	*	Permet de retourner l'image Google Map
	*/		
	public BufferedImage getImage(){
		return map;
	}

	public void ShowError(String erreur){
		JOptionPane Erreur = new JOptionPane();
		Erreur.showMessageDialog(null, erreur, "Erreur", JOptionPane.ERROR_MESSAGE);		
	}
}
